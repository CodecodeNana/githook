/* jshint latedef: true,
undef:true
*/
foo();
