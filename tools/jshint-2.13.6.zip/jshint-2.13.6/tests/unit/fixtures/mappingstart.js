['foo', 'bar', 'baz'].forEach(function(name) {
    console.log(name);
});
