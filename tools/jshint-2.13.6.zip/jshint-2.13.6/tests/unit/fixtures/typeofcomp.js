if (typeof func === 'funtion') {}
if ('double' == typeof func) {}
if (typeof func !== 'bool') {}
if ('obj' != typeof func) {}

if (typeof func === 'undefined') {}
if (typeof func === 'object') {}
if (typeof func === 'boolean') {}
if (typeof func === 'number') {}
if (typeof func === 'string') {}
if (typeof func === 'function') {}
if (typeof func === 'unknown') {}
if (typeof func === 'symbol') {}
if (typeof func === 'bigint') {}
if (typeof func === "xml") {}
if (typeof func === "object") {}
if ("undefined" === typeof func) {}

var a = "functio";
if (typeof func === a) {}
