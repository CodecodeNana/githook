function test() {
  var a = b = 1;
  const c = d = 2;
  let e = f = 3;
}

test();