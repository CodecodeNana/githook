/*jshint unused:true*/

// This commented code should not be recognized as JSHint comment.
// Therefore no error about unused symbols should be reported.
/*globalBus.on('event');*/
/* globalBus.on('event'); */
