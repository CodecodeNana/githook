var someVar = obj[ "key" ] || 0

function f() {
  function g() {

  }
}
