/* global
  foo,
  bar,
*/

foo();
bar();

/* global baz,
  qux,
  pi
*/

baz();
qux();

/* global
fez
*/

fez();
