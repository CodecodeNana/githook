var a;
var c;

function hey() {
    var d, e;
}

function sup() {
    var f;
    var g;
}