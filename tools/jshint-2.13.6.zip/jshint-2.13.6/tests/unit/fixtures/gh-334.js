// Uncommenting this line makes the code below work??
// var a;

[ "Foo", "Bar", "Baz" ].forEach(function(item) {
    console.log(item);
});


/*
Fixing error:

Line 6: ].forEach(function( item ) {
Expected '(end)' and instead saw '.'.

*/
