"use strict";

module.exports = "doc.html";
