---
title: id-blacklist
rule_type: suggestion
---
