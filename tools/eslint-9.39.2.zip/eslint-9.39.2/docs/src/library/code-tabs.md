---
title: Code block tabs
---

This component is a partial found in `/components/code-tabs.html`. To use this component, copy the code for the tabs from the partial and replace the code blocks with the ones you want to render.

## Example

{% include 'components/code-tabs.html' %}
