---
title: Working with Rules (Deprecated)
---

As of ESLint v9.0.0, the function-style rule format that was current in ESLint <= 2.13.1 is no longer supported.

[This is the most recent rule format](./custom-rules).
