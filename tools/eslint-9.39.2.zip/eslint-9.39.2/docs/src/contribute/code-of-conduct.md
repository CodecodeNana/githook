---
title: Code of Conduct
eleventyNavigation:
    key: code of conduct
    parent: contribute to eslint
    title: Code of Conduct
    order: 0
---

ESLint welcomes contributions from everyone and adheres to the [OpenJS Foundation Code of Conduct](https://eslint.org/conduct). We kindly request that you read over this code of conduct before contributing.
