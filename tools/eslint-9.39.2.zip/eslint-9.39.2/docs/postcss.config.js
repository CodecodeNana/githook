"use strict";

module.exports = {
	plugins: [require("autoprefixer"), require("cssnano")],
	map: false,
};
